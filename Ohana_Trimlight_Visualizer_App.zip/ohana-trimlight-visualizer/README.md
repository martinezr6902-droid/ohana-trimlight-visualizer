# Ohana Trimlight Home Visualizer

A mobile-friendly customer app for previewing permanent roofline lighting on a house photo.

## Customer features

- Upload a house photo (processed only in the browser)
- Tap along multiple roofline sections
- Preview warm white, patriotic, Christmas, or celebration colors
- Adjust bulb spacing, glow, and nighttime darkness
- Undo points, reset, and download a PNG mockup
- Prepare a free-estimate email request

## Run locally

```bash
npm start
```

Open `http://localhost:3000`.

## Railway

The included Node server listens on Railway's `PORT` automatically. Connect this repository to a Railway service and deploy with the default start command.

## Before launch

Add the final Ohana Trimlight phone number, email address, social links, privacy policy, and estimate intake destination. The current form opens the visitor's email app without storing personal information.
